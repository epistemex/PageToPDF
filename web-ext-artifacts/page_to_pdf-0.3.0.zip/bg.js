/*
	Background handler
	Copyright (c) 2017 Epistemex
	www.epistemex.com
*/

"use strict";

var _id = "page-to-pdf";

function msgHandler(msg) {
	browser.tabs.saveAsPDF(msg)
		.then(function(status) {

			switch(status.toLowerCase()) {
				case "saved":
				case "replaced":
					notify(browser.i18n.getMessage("pageSavedOK"));
					break;
				case "cancelled":
					break;
				default:
					notify(browser.i18n.getMessage("pageSaveError"));
			}
		})
		.catch(function(error) {
			notify(browser.i18n.getMessage("error") +  error);
		});
}

/**
 *
 * @param {string} msg
 */
function notify(msg) {

	clear();

	browser.notifications.create(_id, {
		"type": "basic",
		"title": "Page To PDF",
		"message": msg,
		"iconUrl": browser.extension.getURL("gfx/pdf_48.png")
	});

	// clear notification automatically
	setTimeout(clear, 3500);

	function clear() {
		browser.notifications.getAll()
			.then(function(all) {
				if (_id in all) browser.notifications.clear(_id);
			})
	}
}

browser.runtime.onMessage.addListener(msgHandler);