/*
	Page To PDF 0.3.0 alpha

	Options handler
	Copyright (c) 2017 Epistemex
	www.epistemex.com
*/

"use strict";

var getEl = document.getElementById.bind(document);
var optMargins = getEl("optMargins");
var optScale = getEl("optScale");

/*
	Setup handlers
 */
optScale.oninput = updateScale;
optMargins.oninput = updateMargins;

document.addEventListener("click", function(e) {

	if (e.target.id === "print") {

		var optPaper = getEl("optPaper").value;
		var optBackground = getEl("optBackground").checked;
		var optLandscape = getEl("optLandscape").checked;
		var optShrink = getEl("optShrink").checked;
		var optMargins = +getEl("optMargins").value;
		var optScale = +getEl("optScale").value;
		var optShowTitle = getEl("optShowTitle").checked;
		var optShowURL = getEl("optShowURL").checked;
		var optShowPageNo = getEl("optShowPageNo").checked;

		// Set Paper Size (def. US Letter)
		var width = 8.5, height = 11, unit = 0;

		if (optPaper === "legal") {	 // ignored for now, in options*.html
			height = 14;
		}
		else if (optPaper === "a4") {
			unit = 1;		// mm
			width = 210;
			height = 297;
		}

		// send options to BG so we can utilize notification
		browser.runtime.sendMessage({
			"showBackgroundImages": optBackground,
			"showBackgroundColors": optBackground,
			"orientation"         : optLandscape ? 1 : 0,
			"paperSizeUnit"       : unit,
			"paperWidth"          : width,
			"paperHeight"         : height,
			"shrinkToFit"         : optShrink,
			"scaling"             : optScale / 100,
			"marginTop"           : optMargins,
			"marginRight"         : optMargins,
			"marginBottom"        : optMargins,
			"marginLeft"          : optMargins,
			"headerLeft"          : optShowTitle ? "&T" : "",	// &T
			"headerCenter"        : "",
			"headerRight"         : "",							// &U
			"footerLeft"          : optShowURL ? "&U" : "",		// &PT
			"footerCenter"        : "",
			"footerRight"         : optShowPageNo ? "&PT" : ""	// &D
		})
	}
	else if (e.target.localName !== "html") {
		//saveOptions();
		updateScale();	// -> saveOptions() as shrink option affects scale slider
	}
});

/*
	Callbacks
 */
function updateScale() {
	getEl("optScaleValue").textContent = getEl("optScale").value;
	optScale.disabled = getEl("optShrink").checked;

	saveOptions();
}

function updateMargins() {
	var v = +optMargins.value;

	// if margins=0, ignore deco. settings
	getEl("optMarginsValue").textContent = v.toFixed(2);
	getEl("optShowTitle").disabled = !v;
	getEl("optShowURL").disabled = !v;
	getEl("optShowPageNo").disabled = !v;

	saveOptions();
}

function saveOptions() {
	//todo there is a microscopic chance that the option win. is closed
	//before this is called (check) - if so, consider deter options to bg.
	browser.storage.local.set({
		options: {
			background: getEl("optBackground").checked,
			landscape : getEl("optLandscape").checked,
			paper     : getEl("optPaper").value,
			shrink    : getEl("optShrink").checked,
			scale     : +optScale.value,
			margins   : +optMargins.value,
			showTitle : getEl("optShowTitle").checked,
			showPageNo: getEl("optShowPageNo").checked,
			showURL   : getEl("optShowURL").checked
		}
	});
}

function loadOptions() {
	browser.storage.local.get({
		// defaults
		options: {
			background: true,
			landscape : false,
			paper     : "letter",
			shrink    : true,
			scale     : 1,
			margins   : 0.5,
			showTitle : false,
			showURL   : false,
			showPageNo: true
		}
	})
	.then(function(items) {
		if (items.options) {
			getEl("optBackground").checked = items.options.background;
			getEl("optLandscape").checked = items.options.landscape;
			getEl("optPaper").value = items.options.paper;
			getEl("optShrink").checked = items.options.shrink;
			getEl("optScale").value = items.options.scale;
			getEl("optMargins").value = items.options.margins;
			getEl("optShowTitle").checked = items.options.showTitle;
			getEl("optShowPageNo").checked = items.options.showPageNo;
			getEl("optShowURL").checked = items.options.showURL;

			updateMargins();
			updateScale();
		}
	});
}

/*
	Init
 */
window.onload = loadOptions;
