/*
	Page To PDF
	Options handler

	Copyright (c) 2017 K3N / Epistemex
	www.epistemex.com
*/

"use strict";

var getEl = document.getElementById.bind(document),

	optPaper = getEl("optPaper"),
	optLandscape = getEl("optLandscape"),
	optBackground = getEl("optBackground"),

	optShrink = getEl("optShrink"),
	optScale = getEl("optScale"),
	optScaleValue = getEl("optScaleValue"),

	optMargins = getEl("optMargins"),
	optMarginsValue = getEl("optMarginsValue"),

	optShowTitle = getEl("optShowTitle"),
	optShowURL = getEl("optShowURL"),
	optShowPageNo = getEl("optShowPageNo");

/*----------------------------------------------------------------------

	Setup handlers

----------------------------------------------------------------------*/

optScale.oninput = updateScale;
optMargins.oninput = updateMargins;
document.onclick = handleClick;

/*----------------------------------------------------------------------

	Callbacks

----------------------------------------------------------------------*/

function handleClick(e) {

	if (e.target.id === "print") {

		var paper = optPaper.value,
			orientation = optLandscape.checked ? 1 : 0,
			background = optBackground.checked,
			shrink = optShrink.checked,
			scale = optScale.value / 100,
			margins = +optMargins.value,
			showTitle = optShowTitle.checked,
			showURL = optShowURL.checked,
			showPageNo = optShowPageNo.checked,

			width = 8.5, height = 11, unit = 0;

		// Set Paper Size (def. US Letter)
		if (paper === "a4") {
			unit = 1;	// mm
			width = 210;
			height = 297;
		}

		// send options to BG so we can utilize notification
		browser.runtime.sendMessage({
			"paperWidth"          : width,
			"paperHeight"         : height,
			"paperSizeUnit"       : unit,
			"orientation"         : orientation,
			"showBackgroundImages": background,
			"showBackgroundColors": background,
			"shrinkToFit"         : shrink,
			"scaling"             : scale,
			"marginTop"           : margins,
			"marginRight"         : margins,
			"marginBottom"        : margins,
			"marginLeft"          : margins,
			"headerLeft"          : showTitle ? "&T" : "",	// &T
			"headerCenter"        : "",
			"headerRight"         : "",						// &U
			"footerLeft"          : showURL ? "&U" : "",	// &PT
			"footerCenter"        : "",
			"footerRight"         : showPageNo ? "&PT" : ""	// &D
		})
		.then(null, onError);
	}
	else if (e.target.localName !== "html") {
		updateScale();	// -> saveOptions() as shrink option affect scale slider
	}
}

function updateScale() {
	optScaleValue.textContent = optScale.value;
	optScale.disabled = optShrink.checked;

	saveOptions();
}

function updateMargins() {
	var v = +optMargins.value;

	// if margins=0, ignore deco. settings
	optMarginsValue.textContent = v.toFixed(2);
	optShowTitle.disabled = !v;
	optShowURL.disabled = !v;
	optShowPageNo.disabled = !v;

	saveOptions();
}

function saveOptions() {
	browser.storage.local.set({
		options: {
			background: optBackground.checked,
			landscape : optLandscape.checked,
			paper     : optPaper.value,
			shrink    : optShrink.checked,
			scale     : +optScale.value,
			margins   : +optMargins.value,
			showTitle : optShowTitle.checked,
			showPageNo: optShowPageNo.checked,
			showURL   : optShowURL.checked
		}
	})
	.then(null, onError);
}

function loadOptions() {
	browser.storage.local.get({

		// defaults
		options: {
			background: true,
			landscape : false,
			paper     : "letter",
			shrink    : true,
			scale     : 100,
			margins   : 0.5,
			showTitle : false,
			showURL   : false,
			showPageNo: true
		}
	})
	.then(function(items) {

		var options = items.options;
		if (options) {
			optBackground.checked = options.background;
			optLandscape.checked = options.landscape;
			optPaper.value = options.paper;
			optShrink.checked = options.shrink;
			optScale.value = options.scale;
			optMargins.value = options.margins;
			optShowTitle.checked = options.showTitle;
			optShowPageNo.checked = options.showPageNo;
			optShowURL.checked = options.showURL;

			updateMargins();
			updateScale();
		}
	}, onError);
}

function onError(err) {
	console.log("Error: ", err)
}

/*----------------------------------------------------------------------

	Init

----------------------------------------------------------------------*/

window.onload = loadOptions;
