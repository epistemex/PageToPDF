/*
	Page 2 PDF 0.2.0 alpha

	Options
	Copyright (c) 2017 Epistemex
	www.epistemex.com
*/

document.addEventListener("click", function(e) {

	if (e.target.id === "print") {

		var optPaper = document.getElementById("optPaper").value;
		var optBackground = document.getElementById("optBackground").checked;
		var optLandscape = document.getElementById("optLandscape").checked;
		var optShrink = document.getElementById("optShrink").checked;

		// Set Paper Size
		var width = 8.5, height = 11, unit = 0;

		if (optPaper === "a4") {
			unit = 1;		// mm
			width = 210;
			height = 297;
		}
		else if (optPaper === "legal") {
			height = 14;
		}

		browser.tabs.saveAsPDF({
			"showBackgroundImages": optBackground,
			"showBackgroundColors": optBackground,
			"orientation"         : optLandscape ? 1 : 0,
			"paperSizeUnit"       : unit,
			"paperWidth"          : width,
			"paperHeight"         : height,
			"shrinkToFit"         : optShrink,
			"marginTop"           : 0,
			"marginRight"         : 0,
			"marginBottom"        : 0,
			"marginLeft"          : 0
		})
		.then(function(status) {
			// todo notification somehow (direct notification: fail, bg msg: fail, content+export+bg msg: fail, not added to download .. hmm)
		})
		.catch(function(error) {
			console.log("An error occurred while saving page as PDF:", error)
		});
	}
	else {
		saveOptions();
	}
});

function saveOptions() {
	browser.storage.local.set({
		options:  {
			background: document.getElementById("optBackground").checked,
			landscape: document.getElementById("optLandscape").checked,
			paper: document.getElementById("optPaper").value,
			shrink: document.getElementById("optShrink").checked
		}
	});
}

function loadOptions() {
	browser.storage.local.get({
		options: {
			background: true,
			landscape: false,
			paper: "letter",
			shrink: true
		}
	})
	.then(function(items) {
		if (items.options) {
			document.getElementById("optBackground").checked = items.options.background;
			document.getElementById("optLandscape").checked = items.options.landscape;
			document.getElementById("optPaper").value = items.options.paper;
			document.getElementById("optShrink").checked = items.options.shrink;
		}
	});
}

loadOptions();
