/*!
	Page To PDF ver 0.1.0 alpha
	Copyright (c) 2017 Epistemex
	www.epistemex.com
*/

browser.browserAction.onClicked.addListener(function() {
	browser.tabs.saveAsPDF({
		"showBackgroundImages": true,
		"showBackgroundColors": true,
		"orientation": 0,
		"marginTop": 0,
		"marginRight": 0,
		"marginBottom": 0,
		"marginLeft": 0
	})
	.then(function(status) {
		//console.log(status);
	});
});
